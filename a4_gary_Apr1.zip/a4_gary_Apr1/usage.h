#ifndef __USAGE_H__
#define __USAGE_H__

void usage(char *);
#endif

