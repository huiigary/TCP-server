#ifndef _DIRH__

#define _DIRH__

int listFiles(int, char*);

#endif
